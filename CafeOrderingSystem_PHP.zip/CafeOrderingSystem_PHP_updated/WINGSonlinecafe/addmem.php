<?php
declare(strict_types=1);

session_start();
require_once __DIR__ . '/connection.php'; // expects $con to be a mysqli connection

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method Not Allowed');
}

$studentnum = trim($_POST['studentnum'] ?? '');
$name       = trim($_POST['name'] ?? '');
$surname    = trim($_POST['surname'] ?? '');
$contacts   = trim($_POST['contacts'] ?? '');
$password   = (string)($_POST['password'] ?? '');
$email      = trim($_POST['email'] ?? '');

if ($studentnum === '' || $name === '' || $surname === '' || $contacts === '' || $password === '' || $email === '') {
    http_response_code(400);
    exit('Missing required fields.');
}

// ✅ PHP 8+ best practice: store a password hash (NOT plaintext).
// If your existing login code compares plaintext passwords, update it to use password_verify().
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

$sql = 'INSERT INTO members (studentnum, name, surname, contacts, password, email)
        VALUES (?, ?, ?, ?, ?, ?)';

$stmt = $con->prepare($sql);
if (!$stmt) {
    http_response_code(500);
    exit('Database prepare failed: ' . htmlspecialchars($con->error));
}

$stmt->bind_param('ssssss', $studentnum, $name, $surname, $contacts, $passwordHash, $email);

if (!$stmt->execute()) {
    http_response_code(500);
    exit('Database insert failed: ' . htmlspecialchars($stmt->error));
}

$stmt->close();
$con->close();

header('Location: loginindex.php');
exit;
?>
