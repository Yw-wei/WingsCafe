<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/connection.php'; // expects $con = new mysqli(...)

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    exit('Method Not Allowed');
}

$email = trim((string)($_POST['email'] ?? ''));
$password = (string)($_POST['password'] ?? '');

if ($email === '' || $password === '') {
    echo "<h4 style='color:red;'>Please enter your login details.</h4>";
    exit;
}

$stmt = $con->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
if (!$stmt) {
    http_response_code(500);
    exit('Server error.');
}

$stmt->bind_param('s', $email);
$stmt->execute();

$result = $stmt->get_result();
$user = $result ? $result->fetch_assoc() : null;

$stmt->close();

if (!$user) {
    echo "<h4 style='color:red;'>Please enter your correct login details!!!</h4>";
    exit;
}

$stored = (string)($user['password'] ?? '');
$ok = false;

/**
 * Compatibility:
 * - If your database still stores plaintext passwords, this allows legacy login.
 * - If you migrate to password_hash(), password_verify() will be used automatically.
 */
if ($stored !== '') {
    if (hash_equals($stored, $password)) {
        $ok = true; // legacy plaintext match
    } elseif (password_get_info($stored)['algo'] !== 0 && password_verify($password, $stored)) {
        $ok = true; // modern hashed match
    }
}

if (!$ok) {
    echo "<h4 style='color:red;'>Please enter your correct login details!!!</h4>";
    exit;
}

// Login success
session_regenerate_id(true);

// Store minimal session info (add more fields here if your other pages need them)
$_SESSION['user_email'] = $user['email'] ?? $email;

// Common optional IDs (if they exist in your table)
if (isset($user['id'])) {
    $_SESSION['user_id'] = $user['id'];
} elseif (isset($user['userid'])) {
    $_SESSION['user_id'] = $user['userid'];
}

// If you have roles (e.g., admin/user), keep it
if (isset($user['role'])) {
    $_SESSION['role'] = $user['role'];
}

session_write_close();

header('Location: home_admin.php');
exit;
?>
