<?php
// Start session
session_start();

// Unset the variables stored in session (logout)
unset($_SESSION['SESS_MEMBER_ID'], $_SESSION['SESS_FIRST_NAME']);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Admin Login</title>

  <link href="style.css" rel="stylesheet" type="text/css">
  <link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css">

  <script src="lib/jquery.js"></script>
  <script src="src/facebox.js"></script>
  <script>
    jQuery(function ($) {
      // Facebox modal support (if used by links on this page)
      $('a[rel*=facebox]').facebox({
        loadingImage: 'src/loading.gif',
        closeImage: 'src/closelabel.png'
      });
    });

    // Simple client-side form validation
    function validateForm() {
      var y = document.forms["login"]["email"].value;
      var a = document.forms["login"]["password"].value;

      if (!y) {
        alert("you must enter your username");
        return false;
      }
      if (!a) {
        alert("you must enter your password");
        return false;
      }
      return true;
    }
  </script>
</head>
<body>
<div id="container">
  <div id="header_section"> 
    <p>&nbsp;</p>
    <p>&nbsp;</p>
  </div>
  <div id="menu_bg">
    <div id="menu">
      <ul>
        <li><a href="index.php"  class="current">Home</a></li>
        <li><a href="aboutus.php">About Us</a></li>
		<li><a href="contact.php">Contact</a></li>
        <li><a href="loginindex.php">Order Now! </a></li>
		<li><a href="admin_index.php">Admin </a></li>
      </ul>
    </div>
  </div>>
  <div id="content">
<div style="width:300px; margin:0 auto; position:relative; border:3px solid rgba(0,0,0,0); -webkit-border-radius:5px; -moz-border-radius:5px; border-radius:5px; -webkit-box-shadow:0 0 18px rgba(0,0,0,0.4); -moz-box-shadow:0 0 18px rgba(0,0,0,0.4); box-shadow:0 0 18px rgba(0,0,0,0.4); margin-top:20px;">
  <form id="form1" name="login" method="post" action="admin.php" onsubmit="return validateForm()">
  <div style=" font-family:Arial, Helvetica, sans-serif; color:#000000; padding:5px; height:22px;"> 
 
 
 <div style="float:left;"><strong>Administrator Login!</strong></div>
 
 
 </div>
  <table width="286" align="center" style ="color:black;">
  <tr>
    <td colspan="2">
	<div style="font-family:Arial, Helvetica, sans-serif; color:#FF0000; font-size:12px;"></div>
	</td>
  </tr>
  <tr>
    <td width="92"><div align="right">UserName</div></td>
    <td width="178"><input type="text" name="email" /></td>
  </tr>
  <tr>
    <td><div align="right">Password:</div></td>
    <td>
      <input type="password" name="password" />
    </td>
  </tr>

  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="Submit" value="login" /></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
</table>
   </div> 
 

</body>
</html>