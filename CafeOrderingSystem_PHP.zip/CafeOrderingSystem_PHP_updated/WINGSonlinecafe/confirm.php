<?php
declare(strict_types=1);

require_once 'auth.php';
require_once 'connection.php'; // expects: $con = new mysqli(...)

if (!isset($con) || !($con instanceof mysqli)) {
    http_response_code(500);
    echo 'Database connection is not available. Ensure connection.php creates $con as a mysqli instance.';
    exit;
}

$con->set_charset('utf8mb4');

function post_trimmed(string $key): ?string {
    if (!isset($_POST[$key])) {
        return null;
    }
    $v = trim((string)$_POST[$key]);
    return $v === '' ? null : $v;
}

$totalRaw = post_trimmed('total');
$transactionCode = post_trimmed('transactioncode');
$studentInput = post_trimmed('student') ?? post_trimmed('studentnum'); // optional, if your form asks for it

if ($totalRaw === null || $transactionCode === null) {
    http_response_code(400);
    echo 'Missing required order details (total / transactioncode).';
    exit;
}

$total = filter_var($totalRaw, FILTER_VALIDATE_FLOAT);
if ($total === false || $total < 0) {
    http_response_code(400);
    echo 'Invalid total amount.';
    exit;
}

$memberSessionId = $_SESSION['SESS_MEMBER_ID'] ?? null;
if ($memberSessionId === null || trim((string)$memberSessionId) === '') {
    http_response_code(401);
    echo 'Not authenticated.';
    exit;
}

/**
 * Resolve the logged-in customer's student number.
 * This script tries common ID column names in the `members` table.
 * If your schema differs, adjust the $possibleIdCols list.
 */
$studentFromDb = null;
$membersCols = [];
if ($res = $con->query('SHOW COLUMNS FROM members')) {
    while ($row = $res->fetch_assoc()) {
        $membersCols[] = $row['Field'];
    }
    $res->free();
}

$possibleIdCols = ['member_id', 'id', 'mem_id', 'user_id', 'userid'];
$idCol = null;
foreach ($possibleIdCols as $c) {
    if (in_array($c, $membersCols, true)) {
        $idCol = $c;
        break;
    }
}

if ($idCol !== null) {
    $sql = "SELECT studentnum FROM members WHERE {$idCol} = ? LIMIT 1";
    $stmt = $con->prepare($sql);
    if (!$stmt) {
        http_response_code(500);
        echo 'Database error (prepare members lookup).';
        exit;
    }
    $sid = (string)$memberSessionId;
    $stmt->bind_param('s', $sid);
    $stmt->execute();
    $stmt->bind_result($studentFromDb);
    $stmt->fetch();
    $stmt->close();
} else {
    // Fallback: some projects store student number directly in the session.
    $studentFromDb = (string)$memberSessionId;
}

if ($studentFromDb === null || trim((string)$studentFromDb) === '') {
    http_response_code(400);
    echo 'Could not resolve your student number. Check your members table schema / session value.';
    exit;
}

// Optional extra validation (if your UI asks user to re-enter their student number)
if ($studentInput !== null && $studentInput !== $studentFromDb) {
    echo 'wrong student Num';
    exit;
}

/**
 * Insert into wings_orders.
 * This script detects common column names to reduce schema mismatch issues.
 * If needed, adjust the candidate lists below to match your SQL file.
 */
$orderCols = [];
if ($res = $con->query('SHOW COLUMNS FROM wings_orders')) {
    while ($row = $res->fetch_assoc()) {
        $orderCols[] = $row['Field'];
    }
    $res->free();
} else {
    http_response_code(500);
    echo 'Database error: wings_orders table not found or not accessible.';
    exit;
}

function pick_col(array $available, array $candidates): ?string {
    foreach ($candidates as $c) {
        if (in_array($c, $available, true)) {
            return $c;
        }
    }
    return null;
}

$colCusId = pick_col($orderCols, ['cusid', 'customer_id', 'cust_id', 'member_id', 'studentnum']);
$colTotal = pick_col($orderCols, ['total', 'amount', 'grand_total']);
$colDate  = pick_col($orderCols, ['transactiondate', 'transaction_date', 'trans_date', 'date_created', 'created_at']);
$colCode  = pick_col($orderCols, ['transactioncode', 'transaction_code', 'trx_code', 'reference', 'ref_code']);

if (!$colCusId || !$colTotal || !$colDate || !$colCode) {
    http_response_code(500);
    echo 'Schema mismatch in wings_orders table. Expected columns similar to: cusid/total/transactiondate/transactioncode.';
    exit;
}

$transactionDate = date('Y-m-d H:i:s');

// Dynamic column names are safe here because they are chosen from the table's actual columns.
$insertSql = "INSERT INTO wings_orders ({$colCusId}, {$colTotal}, {$colDate}, {$colCode}) VALUES (?, ?, ?, ?)";
$stmt = $con->prepare($insertSql);
if (!$stmt) {
    http_response_code(500);
    echo 'Database error (prepare insert).';
    exit;
}

$stud = (string)$studentFromDb;
$code = (string)$transactionCode;
$stmt->bind_param('sdss', $stud, $total, $transactionDate, $code);

if (!$stmt->execute()) {
    http_response_code(500);
    echo 'Database error (insert failed).';
    exit;
}
$stmt->close();
?>
<div style="text-align:center; padding:10px;">
  <h3 style="margin:0 0 10px 0;">Order confirmed ✅</h3>
  <p style="margin:0 0 12px 0;">Transaction code: <strong><?php echo htmlspecialchars($transactionCode, ENT_QUOTES, 'UTF-8'); ?></strong></p>
  <a rel="facebox" href="order.php"><img src="images/28.png" width="75" height="75" alt="Back to order" /></a>
</div>
