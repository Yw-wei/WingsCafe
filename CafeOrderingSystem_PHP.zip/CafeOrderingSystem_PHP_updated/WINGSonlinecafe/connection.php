<?php
declare(strict_types=1);

/**
 * PHP 8+ database connection (MySQLi) using AWS SSM Parameter Store.
 * Required parameters (case sensitive):
 *   /example/endpoint
 *   /example/username
 *   /example/password
 *   /example/database
 */

function ssm_get(string $name, bool $decrypt = false): string
{
    // On Amazon Linux, AWS CLI is usually here. Fallback to PATH.
    $aws = file_exists('/usr/bin/aws') ? '/usr/bin/aws' : 'aws';

    $cmd = $aws
        . ' ssm get-parameter'
        . ' --name ' . escapeshellarg($name)
        . ($decrypt ? ' --with-decryption' : '')
        . ' --query Parameter.Value'
        . ' --output text'
        . ' 2>/dev/null';

    $out = shell_exec($cmd);
    return $out === null ? '' : trim($out);
}

// Optional: allow env vars if you later choose to set them via user-data
$mysql_hostname = getenv('DB_HOST') ?: ssm_get('/example/endpoint');
$mysql_user     = getenv('DB_USER') ?: ssm_get('/example/username');
$mysql_password = getenv('DB_PASS') ?: ssm_get('/example/password', true);
$mysql_database = getenv('DB_NAME') ?: ssm_get('/example/database');

if ($mysql_hostname === '' || $mysql_user === '' || $mysql_password === '' || $mysql_database === '') {
    http_response_code(500);
    exit('Server configuration error.');
}

$con = new mysqli($mysql_hostname, $mysql_user, $mysql_password, $mysql_database);

if ($con->connect_errno) {
    http_response_code(500);
    exit('Database connection failed.');
}

$con->set_charset('utf8mb4');
?>