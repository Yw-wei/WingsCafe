<?php
declare(strict_types=1);

require_once __DIR__ . '/connection.php';

// Expect an integer id like: deleteorder.php?id=123
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if ($id === null || $id === false) {
    // Invalid or missing id — just go back to orders page
    header('Location: order.php');
    exit;
}

$stmt = $con->prepare('DELETE FROM orderditems WHERE id = ?');
if (!$stmt) {
    http_response_code(500);
    exit('Database error.');
}

$stmt->bind_param('i', $id);
$stmt->execute();
$stmt->close();

header('Location: order.php');
exit;
?>
