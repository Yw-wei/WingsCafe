<?php
declare(strict_types=1);

/**
 * listorder.php (PHP 8+)
 * Shows ordered items for a given transaction code (?id=...).
 *
 * Requires: connection.php that defines $con = new mysqli(...);
 */

$transactionCode = isset($_GET['id']) ? trim((string)$_GET['id']) : '';
if ($transactionCode === '' || strlen($transactionCode) > 100) {
    http_response_code(400);
    exit('Invalid request.');
}

require_once __DIR__ . '/connection.php';

if (!isset($con) || !($con instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection not available.');
}

?>
<style type="text/css">
.style1 { color: #FFFFFF; }
</style>

<table width="249" border="1" cellpadding="0" cellspacing="0">
  <tr>
    <td width="189"><div align="left">&nbsp;&nbsp;&nbsp;&nbsp;Products</div></td>
    <td width="65">Price</td>
    <td width="50">Qty</td>
  </tr>

<?php
$stmt = $con->prepare("SELECT product, price, qty FROM orderditems WHERE transactioncode = ?");
if (!$stmt) {
    http_response_code(500);
    exit('Query preparation failed.');
}

$stmt->bind_param('s', $transactionCode);
$stmt->execute();
$result = $stmt->get_result();

$found = false;
while ($row = $result->fetch_assoc()) {
    $found = true;
    $product = htmlspecialchars((string)($row['product'] ?? ''), ENT_QUOTES, 'UTF-8');
    $priceRaw = $row['price'] ?? '';
    $qtyRaw   = $row['qty'] ?? '';

    // Keep formatting flexible (some DBs store price/qty as VARCHAR)
    $price = htmlspecialchars((string)$priceRaw, ENT_QUOTES, 'UTF-8');
    $qty   = htmlspecialchars((string)$qtyRaw, ENT_QUOTES, 'UTF-8');

    echo "<tr>";
    echo "<td><div align='left'>&nbsp;&nbsp;&nbsp;&nbsp;{$product}</div></td>";
    echo "<td>{$price}</td>";
    echo "<td>{$qty}</td>";
    echo "</tr>";
}

$stmt->close();

if (!$found) {
    echo "<tr><td colspan='3' style='padding:8px;'>No items found for this order.</td></tr>";
}
?>
</table>
