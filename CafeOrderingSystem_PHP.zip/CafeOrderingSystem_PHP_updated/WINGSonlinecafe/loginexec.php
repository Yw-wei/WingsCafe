<?php
declare(strict_types=1);

// Start session
session_start();

// DB connection (expects $con = new mysqli(...);)
require_once __DIR__ . '/connection.php';

$errmsg_arr = [];
$errflag = false;

/**
 * Generate an 8-character random code.
 * (Kept for backward compatibility with the original app behaviour:
 * it stores this in $_SESSION['SESS_FIRST_NAME'] and uses it as a transaction/session code.)
 */
function createRandomPassword(int $length = 8): string
{
    $chars = 'abcdefghijkmnopqrstuvwxyz023456789'; // no l, no 1
    $max = strlen($chars) - 1;

    $out = '';
    for ($i = 0; $i < $length; $i++) {
        $out .= $chars[random_int(0, $max)];
    }
    return $out;
}

// Read inputs
$loginRaw    = $_POST['user'] ?? '';
$passwordRaw = $_POST['password'] ?? '';

$login = trim((string)$loginRaw);
$password = trim((string)$passwordRaw);

// Basic validation
if ($login === '' || $password === '') {
    $errmsg_arr[] = 'Email and password are required.';
    $errflag = true;
}

// If you want to enforce email format, uncomment:
// if ($login !== '' && !filter_var($login, FILTER_VALIDATE_EMAIL)) {
//     $errmsg_arr[] = 'Please enter a valid email address.';
//     $errflag = true;
// }

if ($errflag) {
    $_SESSION['ERRMSG_ARR'] = $errmsg_arr;
    session_write_close();
    header('Location: loginindex.php');
    exit;
}

// Query by email (use prepared statement for PHP 8+ compatibility + SQLi safety)
$stmt = $con->prepare('SELECT id, email, password FROM members WHERE email = ? LIMIT 1');
if (!$stmt) {
    http_response_code(500);
    exit('Server error.');
}

$stmt->bind_param('s', $login);
$stmt->execute();
$res = $stmt->get_result();

if ($res && $res->num_rows === 1) {
    $member = $res->fetch_assoc();

    $dbPass = (string)($member['password'] ?? '');

    // Support BOTH:
    // 1) New secure hashes (password_hash) and
    // 2) Legacy plaintext passwords (old projects often store plaintext)
    $passwordOk = false;

    if ($dbPass !== '') {
        // password_verify() returns false if $dbPass isn't a valid hash — that's OK.
        if (password_verify($password, $dbPass)) {
            $passwordOk = true;
        } elseif (hash_equals($dbPass, $password)) {
            $passwordOk = true;
        }
    }

    if ($passwordOk) {
        // Login successful
        session_regenerate_id(true);

        $_SESSION['SESS_MEMBER_ID']  = (int)$member['id'];
        $_SESSION['SESS_FIRST_NAME'] = createRandomPassword(); // legacy session key used by the app

        // Extra helpful session values (won't break old code)
        $_SESSION['email']      = (string)$member['email'];   // legacy
        $_SESSION['user_email'] = (string)$member['email'];   // new

        session_write_close();
        header('Location: order.php');
        exit;
    }
}

// Login failed (generic message)
$errmsg_arr[] = 'Invalid email address or password.';
$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
session_write_close();
header('Location: loginindex.php');
exit;
?>