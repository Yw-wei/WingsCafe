<?php
declare(strict_types=1);

// Start session
session_start();

// Treat this page as a fresh login entry point (clear any existing login session)
unset($_SESSION['SESS_MEMBER_ID'], $_SESSION['SESS_FIRST_NAME'], $_SESSION['email'], $_SESSION['user_email']);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Wings Cafe</title>

  <link href="css/main.css" rel="stylesheet" type="text/css">
  <link href="style.css" rel="stylesheet" type="text/css">

  <!-- Facebox popup (kept for compatibility with the original template) -->
  <link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css">
  <script src="lib/jquery.js" type="text/javascript"></script>
  <script src="src/facebox.js" type="text/javascript"></script>
  <script type="text/javascript">
    jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox({
        loadingImage : 'src/loading.gif',
        closeImage   : 'src/closelabel.png'
      });
    });
  </script>

  <!-- Form validation -->
  <script type="text/javascript">
    function validateForm() {
      var y = document.forms["login"]["user"].value;
      var a = document.forms["login"]["password"].value;

      if (y === null || y.trim() === "") {
        alert("You must enter your email");
        return false;
      }
      if (a === null || a.trim() === "") {
        alert("You must enter your password");
        return false;
      }
      return true;
    }
  </script>
</head>

<body>
  <div id="container">
    <div id="header_section">
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    </div>

    <div id="menu_bg">
      <div id="menu">
        <ul>
          <li><a href="index.php" class="current">Home</a></li>
          <li><a href="aboutus.php">About Us</a></li>
          <li><a href="contact.php">Contact</a></li>
          <li><a href="loginindex.php">Order Now!</a></li>
          <li><a href="admin_index.php">Admin</a></li>
        </ul>
      </div>
    </div>

    <div id="content">
      <div style="width:300px; margin:0 auto; position:relative; border:2px solid #DDD; border-radius:10px; padding:10px; box-shadow:0 0 18px rgba(0,0,0,0.4); margin-top:20px; color:#000000;">
        <form id="form1" name="login" method="post" action="loginexec.php" onsubmit="return validateForm()">
          <div style="font-family:Arial, Helvetica, sans-serif; color:#000000; padding:5px; height:22px;">
            <div style="float:left;"><strong>Members Login</strong></div>
          </div>

          <table width="286" align="center">
            <tr>
              <td colspan="2">
                <div style="font-family:Arial, Helvetica, sans-serif; color:#FF0000; font-size:12px;">
                  <?php
                    if (isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) > 0) {
                      echo '<ul class="err">';
                      foreach ($_SESSION['ERRMSG_ARR'] as $msg) {
                        echo '<li>', htmlspecialchars((string)$msg, ENT_QUOTES, 'UTF-8'), '</li>';
                      }
                      echo '</ul>';
                      unset($_SESSION['ERRMSG_ARR']);
                    }
                  ?>
                </div>
              </td>
            </tr>

            <tr>
              <td width="92"><div align="right">Email:</div></td>
              <td width="178"><input type="text" name="user"></td>
            </tr>

            <tr>
              <td><div align="right">Password:</div></td>
              <td><input type="password" name="password"></td>
            </tr>

            <tr>
              <td colspan="2"><div align="center"><input type="submit" value="Login"></div></td>
            </tr>

            <tr>
              <td colspan="2">&nbsp;</td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</body>
</html>
