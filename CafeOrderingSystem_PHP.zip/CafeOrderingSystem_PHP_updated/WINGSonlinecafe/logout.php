<?php
declare(strict_types=1);

session_start();

// Clear all session variables
$_SESSION = [];

// Delete the session cookie (if any)
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params['path'] ?? '/',
        $params['domain'] ?? '',
        (bool)($params['secure'] ?? false),
        (bool)($params['httponly'] ?? true)
    );
}

// Destroy the session
session_destroy();

// Redirect to login page
header('Location: loginindex.php');
exit;
?>