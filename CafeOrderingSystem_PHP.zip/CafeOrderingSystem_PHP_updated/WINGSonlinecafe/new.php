<?php
declare(strict_types=1);

// Start session
session_start();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Wings Cafe</title>

  <link rel="stylesheet" href="style.css">
  <link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css">
  <script src="lib/jquery.js" type="text/javascript"></script>
  <script src="src/facebox.js" type="text/javascript"></script>
  <script type="text/javascript">
    jQuery(function($){
      $('a[rel*=facebox]').facebox({
        loadingImage : 'src/loading.gif',
        closeImage   : 'src/closelabel.png'
      });
    });
  </script>

  <script type="text/javascript">
    function validateForm() {
      const f = document.forms["abc"];

      const studentnum = (f["studentnum"].value || "").trim();
      const name       = (f["name"].value || "").trim();
      const surname    = (f["surname"].value || "").trim();
      const email      = (f["email"].value || "").trim();
      const password   = (f["password"].value || "").trim();
      const ambot      = (f["ambot"].value || "").trim();
      const contacts   = (f["contacts"].value || "").trim();

      if (!studentnum) { alert("Please enter your student number."); return false; }
      if (!name)       { alert("Please enter your first name."); return false; }
      if (!surname)    { alert("Please enter your last name."); return false; }
      if (!email)      { alert("Please enter your email."); return false; }
      if (!password)   { alert("Please enter your password."); return false; }
      if (!ambot)      { alert("Please retype your password."); return false; }

      if (password !== ambot) {
        alert("Passwords do not match.");
        return false;
      }

      if (!contacts) {
        alert("Please enter your contact number.");
        return false;
      }

      // Allow +, spaces, and digits, but if you want strictly digits, use: /^[0-9]+$/
      if (!/^[0-9]+$/.test(contacts)) {
        alert("Contact number must contain digits only.");
        return false;
      }

      return true;
    }

    // Force numeric-only entry for contact number
    document.addEventListener("DOMContentLoaded", function () {
      const el = document.getElementById("contacts");
      const msg = document.getElementById("errmsg");

      if (!el) return;

      el.addEventListener("input", function () {
        const clean = this.value.replace(/[^0-9]/g, "");
        if (clean !== this.value) {
          this.value = clean;
          if (msg) msg.textContent = "Digits only";
        } else {
          if (msg) msg.textContent = "";
        }
      });
    });
  </script>
</head>

<body>
  <div id="container">
    <div id="header_section">
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    </div>

    <div id="menu_bg">
      <div id="menu">
        <ul>
          <li><a href="index.php" class="current">Home</a></li>
          <li><a href="aboutus.php">About Us</a></li>
          <li><a href="contact.php">Contact</a></li>
          <li><a href="loginindex.php">Order Now!</a></li>
          <li><a href="admin_index.php">Admin</a></li>
        </ul>
      </div>
    </div>

    <div id="content">
      <div style="width:400px; margin:0 auto; position:relative; border:2px solid #DDD; border-radius:10px; padding:10px; box-shadow:0 0 18px rgba(0,0,0,0.4); margin-top:20px; color:#000000;">
        <form id="form1" name="abc" method="post" action="addmem.php" onsubmit="return validateForm()">
          <div style="font-family:Arial, Helvetica, sans-serif; color:#000000; padding:5px; height:22px; width:390px;">
            <div style="float:left;"><strong>Members Registration of Wings Cafe</strong></div>
          </div>

          <table width="368" align="center">
            <tr>
              <td colspan="2">
                <div style="font-family:Arial, Helvetica, sans-serif; color:#FF0000; font-size:12px;">
                  <?php
                    if (isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) > 0) {
                      echo '<ul class="err">';
                      foreach ($_SESSION['ERRMSG_ARR'] as $msg) {
                        echo '<li>', htmlspecialchars((string)$msg, ENT_QUOTES, 'UTF-8'), '</li>';
                      }
                      echo '</ul>';
                      unset($_SESSION['ERRMSG_ARR']);
                    }
                  ?>
                </div>
              </td>
            </tr>

            <tr>
              <td valign="top"><div align="right">Student No:</div></td>
              <td><input type="text" name="studentnum" /></td>
            </tr>

            <tr>
              <td valign="top"><div align="right">Firstname:</div></td>
              <td><input type="text" name="name" /></td>
            </tr>

            <tr>
              <td valign="top"><div align="right">Lastname:</div></td>
              <td><input type="text" name="surname" /></td>
            </tr>

            <tr>
              <td valign="top"><div align="right">Email:</div></td>
              <td><input type="text" name="email" /></td>
            </tr>

            <tr>
              <td valign="top"><div align="right">Password:</div></td>
              <td><input type="password" name="password" /></td>
            </tr>

            <tr>
              <td valign="top"><div align="right">Retype Password:</div></td>
              <td><input type="password" name="ambot" /></td>
            </tr>

            <tr>
              <td valign="top"><div align="right">Contact Number:</div></td>
              <td>
                <input name="contacts" type="text" id="contacts" size="18" />
                <span style="font-family:Arial, Helvetica, sans-serif; color:#FF0000; font-size:11px; font-weight:bold;" id="errmsg"></span>
              </td>
            </tr>

            <tr>
              <td colspan="2"><div align="center"><input type="submit" value="Register"></div></td>
            </tr>

            <tr>
              <td colspan="2"><div align="center" style="padding-top:10px;">
                Already a member? <a href="loginindex.php">Login here</a>
              </div></td>
            </tr>
          </table>
        </form>
      </div>
    </div>

    <div id="footer">
      <div class="top"></div>
      <div class="middle">Copyright &copy; Wings Cafe 2013</div>
      <div class="button"></div>
    </div>
  </div>
</body>
</html>
