<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';        // requires logged-in user (uses session)
require_once __DIR__ . '/connection.php';  // expects: $con = new mysqli(...)

$productKey = trim((string)($_GET['id'] ?? ''));
if ($productKey === '') {
    http_response_code(400);
    exit('Missing product id.');
}

$idInt = ctype_digit($productKey) ? (int)$productKey : 0;

// Fetch product (support both product_id and id to match different DB schemas)
$stmt = $con->prepare('SELECT * FROM products WHERE product_id = ? OR id = ? LIMIT 1');
if (!$stmt) {
    http_response_code(500);
    exit('Server error.');
}
$stmt->bind_param('si', $productKey, $idInt);
$stmt->execute();
$res = $stmt->get_result();
$product = $res ? $res->fetch_assoc() : null;
$stmt->close();

if (!$product) {
    http_response_code(404);
    exit('Product not found.');
}

$productName  = (string)($product['name'] ?? '');
$productPhoto = (string)($product['product_photo'] ?? '');
$productPrice = (float)($product['price'] ?? 0);

$error = '';

// Handle "add to cart" submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $qty = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT, [
        'options' => ['min_range' => 1, 'max_range' => 99]
    ]);

    if ($qty === false || $qty === null) {
        $error = 'Please enter a valid quantity (1-99).';
    } else {
        $transactionCode = (string)($_SESSION['SESS_FIRST_NAME'] ?? '');
        $customerId = (int)($_SESSION['SESS_MEMBER_ID'] ?? 0);

        if ($transactionCode === '' || $customerId <= 0) {
            // If auth.php allowed access but session keys are missing, fail safely
            http_response_code(403);
            exit('Session expired. Please log in again.');
        }

        $total = $productPrice * (int)$qty;

        $ins = $con->prepare('INSERT INTO orderditems (name, price, quantity, total, transactioncode, customer) VALUES (?, ?, ?, ?, ?, ?)');
        if (!$ins) {
            http_response_code(500);
            exit('Server error.');
        }

        $ins->bind_param('sdidsi', $productName, $productPrice, $qty, $total, $transactionCode, $customerId);

        if ($ins->execute()) {
            $ins->close();
            // Back to the main order page (the popup will close when user returns)
            header('Location: order.php');
            exit;
        }

        $error = 'Failed to add item. Please try again.';
        $ins->close();
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo htmlspecialchars($productName, ENT_QUOTES, 'UTF-8'); ?> - Add to Order</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .portal-wrap { font-family: Arial, Helvetica, sans-serif; padding: 12px; color: #000; }
    .portal-card { border: 2px solid #DDD; border-radius: 10px; padding: 12px; box-shadow: 0 0 18px rgba(0,0,0,0.15); }
    .portal-row { display: flex; gap: 12px; align-items: center; }
    .portal-img img { max-width: 120px; max-height: 120px; border-radius: 8px; border: 1px solid #eee; object-fit: cover; }
    .portal-meta { flex: 1; }
    .portal-title { font-size: 18px; font-weight: bold; margin-bottom: 6px; }
    .portal-price { margin-bottom: 10px; }
    .portal-error { color: #b00020; font-size: 12px; margin: 8px 0; }
    .portal-actions { margin-top: 10px; }
    input[type="number"] { width: 90px; padding: 6px; }
    button { padding: 8px 12px; cursor: pointer; }
  </style>
</head>
<body>
  <div class="portal-wrap">
    <div class="portal-card">
      <div class="portal-row">
        <div class="portal-img">
          <?php if ($productPhoto !== ''): ?>
            <img src="<?php echo htmlspecialchars('images/' . $productPhoto, ENT_QUOTES, 'UTF-8'); ?>" alt="">
          <?php endif; ?>
        </div>

        <div class="portal-meta">
          <div class="portal-title"><?php echo htmlspecialchars($productName, ENT_QUOTES, 'UTF-8'); ?></div>
          <div class="portal-price">Price: <strong><?php echo htmlspecialchars(number_format($productPrice, 2), ENT_QUOTES, 'UTF-8'); ?></strong></div>

          <?php if ($error !== ''): ?>
            <div class="portal-error"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
          <?php endif; ?>

          <form method="post" action="">
            <label>
              Quantity:
              <input type="number" name="quantity" min="1" max="99" value="1" required>
            </label>

            <div class="portal-actions">
              <button type="submit">Add to Order</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
