<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';        // ensures user is logged in (starts session)
require_once __DIR__ . '/connection.php';  // expects: $con = new mysqli(...)

if (!isset($con) || !($con instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection not available.');
}

// Always trust server-side session, not POSTed customer/transcode
$customerId = (int)($_SESSION['SESS_MEMBER_ID'] ?? 0);
$transcode  = (string)($_SESSION['SESS_FIRST_NAME'] ?? '');

$qty = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT, [
    'options' => ['min_range' => 1, 'max_range' => 99]
]);

$name  = trim((string)($_POST['name'] ?? ''));
$price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);

if ($customerId <= 0 || $transcode === '') {
    // Should not happen if auth.php is correct, but fail safely
    header('Location: loginindex.php');
    exit;
}

if ($qty === false || $qty === null) {
    $_SESSION['ERRMSG_ARR'] = ['Invalid quantity.'];
    header('Location: order.php');
    exit;
}

if ($name === '' || $price === false || $price === null) {
    $_SESSION['ERRMSG_ARR'] = ['Missing item details. Please try again.'];
    header('Location: order.php');
    exit;
}

$total = (float)$price * (int)$qty;

// Insert into orderditems
$stmt = $con->prepare('INSERT INTO orderditems (customer, quantity, price, total, name, transactioncode) VALUES (?, ?, ?, ?, ?, ?)');
if (!$stmt) {
    http_response_code(500);
    exit('Server error.');
}

$stmt->bind_param('iidsss', $customerId, $qty, $price, $total, $name, $transcode);

if (!$stmt->execute()) {
    $_SESSION['ERRMSG_ARR'] = ['Failed to add item to your order.'];
    $stmt->close();
    header('Location: order.php');
    exit;
}

$stmt->close();
header('Location: order.php');
exit;
?>