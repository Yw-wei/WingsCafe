<?php
declare(strict_types=1);

/**
 * Session helper (PHP 8+)
 * 
 * Usage (top of a protected page):
 *   require_once __DIR__ . '/session.php';
 *   logged_in('loginindex.php');   // or admin_index.php
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/**
 * Ensure the user is logged in (checks common session keys used by this project).
 * Redirects to $redirect if not logged in.
 */
function logged_in(string $redirect = 'loginindex.php'): void
{
    $memberId = $_SESSION['SESS_MEMBER_ID'] ?? null;
    $transCode = $_SESSION['SESS_FIRST_NAME'] ?? null;

    if (empty($memberId) || empty($transCode)) {
        if (!headers_sent()) {
            header('Location: ' . $redirect);
            exit;
        }

        // Fallback if output already started
        echo '<script>window.location.href=' . json_encode($redirect) . ';</script>';
        exit;
    }
}
?>