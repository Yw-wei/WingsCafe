<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';        // session/login guard
require_once __DIR__ . '/connection.php';  // expects: $con = new mysqli(...)
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>View Orders</title>

  <link href="css/ble.css" rel="stylesheet" type="text/css">
  <link href="css/main.css" rel="stylesheet" type="text/css">
  <link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css">
  <link href="./febe/style.css" rel="stylesheet" type="text/css">

  <script src="lib/jquery.js" type="text/javascript"></script>
  <script src="src/facebox.js" type="text/javascript"></script>
  <script type="text/javascript">
    jQuery(function($) {
      $('a[rel*=facebox]').facebox({
        loadingImage : 'src/loading.gif',
        closeImage   : 'src/closelabel.png'
      });
    });
  </script>

  <!-- Optional table filter/sort scripts used by the original template -->
  <script src="argiepolicarpio.js" type="text/javascript" charset="utf-8"></script>
  <script src="./js/application.js" type="text/javascript" charset="utf-8"></script>

  <style type="text/css">
    a:link { text-decoration: none; }
    a:visited { text-decoration: none; }
    a:hover { text-decoration: underline; }
    a:active { text-decoration: none; }
  </style>
</head>

<body>
  <div style="width:900px; margin:0 auto; position:relative; border:3px solid #DDD; padding:10px; border-radius:10px; box-shadow:1px 1px 20px rgba(0,0,0,0.25); margin-top:40px; height:400px; overflow:auto;">
    <label style="margin-left:12px;">Filter</label>
    <input type="text" name="filter" value="" id="filter">
    <br><br>

    <table cellpadding="1" cellspacing="1" id="resultTable" border="1">
      <thead>
        <tr bgcolor="#cccccc" style="margin-bottom:10px;">
          <th>Student Num</th>
          <th>Amount Paid</th>
          <th>Code (click to view order)</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        <?php
          // Fetch orders
          $sql = "SELECT cusid, total, transactioncode, transactiondate
                  FROM wings_orders
                  ORDER BY transactiondate DESC";

          $res = $con->query($sql);

          if ($res) {
              while ($row = $res->fetch_assoc()) {
                  $cusid = (string)($row['cusid'] ?? '');
                  $total = (float)($row['total'] ?? 0);
                  $code  = (string)($row['transactioncode'] ?? '');
                  $date  = (string)($row['transactiondate'] ?? '');

                  echo '<tr>';
                  echo '<td>' . htmlspecialchars($cusid, ENT_QUOTES, 'UTF-8') . '</td>';
                  echo '<td>' . 'M' . htmlspecialchars(number_format($total, 2), ENT_QUOTES, 'UTF-8') . '</td>';

                  $href = 'listorder.php?id=' . rawurlencode($code);
                  echo '<td><a rel="facebox" href="' . htmlspecialchars($href, ENT_QUOTES, 'UTF-8') . '">'
                        . htmlspecialchars($code, ENT_QUOTES, 'UTF-8')
                        . '</a></td>';

                  echo '<td>' . htmlspecialchars($date, ENT_QUOTES, 'UTF-8') . '</td>';
                  echo '</tr>';
              }
              $res->free();
          } else {
              echo '<tr><td colspan="4">No orders found.</td></tr>';
          }
        ?>
      </tbody>
    </table>
  </div>
</body>
</html>
